﻿using Newtonsoft.Json;
using System.ComponentModel;

namespace Algorand.Algod.Model
{
    public class KeyRegisterOfflineTransaction : KeyRegistrationTransaction
    {


    
    }
}
