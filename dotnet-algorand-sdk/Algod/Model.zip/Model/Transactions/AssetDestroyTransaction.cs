﻿
namespace Algorand.Algod.Model
{

    public class AssetDestroyTransaction : AssetChangeTransaction
    {
        
    }
}
