﻿namespace Algorand.Algod.Model
{
    using System = global::System;


    /// <summary>Represents a key-value store for use in an application.</summary>
    [System.CodeDom.Compiler.GeneratedCode("NJsonSchema", "10.5.2.0 (Newtonsoft.Json v12.0.0.0)")]
    public partial class TealKeyValueStore : System.Collections.ObjectModel.Collection<TealKeyValue>
    {

    }
}
